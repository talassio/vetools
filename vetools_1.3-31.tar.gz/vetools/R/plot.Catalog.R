#' @export
plot.Catalog <- function(x, ...) {
        panomapa(x)
}