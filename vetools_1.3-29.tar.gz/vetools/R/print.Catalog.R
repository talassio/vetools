print.Catalog <- function(x, ...) {
        panorama(x)
}